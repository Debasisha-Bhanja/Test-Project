package com.util.mail;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MailUtility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MailUtility util = new MailUtility();
		try {
			util.sendMail();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void sendMail() throws AddressException, MessagingException 
	  {
	  	String smtpHost = "smtp.gmail.com";
	  	String smtpPort = "465";
	  	String from = "debasisha.bhanja@gmail.com";
	  	String subject = "Test Mail";
	  	String to ="debasisha.bhanja@gmail.com";
	  	String content = "test mail ....";
	  	//Absolute path of attachment file location
	  	String attachmentFile ="C:\\test.txt"; 
	  	
		Properties props = System.getProperties();

		// Setup mail server
		props.put("mail.smtp.host", smtpHost);
		props.put("mail.smtp.starttls.enable","true");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.socketFactory.fallback", "false");
		props.setProperty("mail.smtp.quitwait", "false");


		// Get session
		
		Session session = Session.getInstance(props, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("debasisha.bhanja@gmail.com", "******");
				}});

		// Define message
		MimeMessage message = new MimeMessage(session);
		message.setFrom( new InternetAddress(from));
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
		message.setSubject("Automated Test Mail");

		// create the message part 
		MimeBodyPart messageBodyPart =  new MimeBodyPart();
		
		//fill message
		messageBodyPart.setText("Hi");

		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart);
		//"multipart/alternative"
		BodyPart bp2 = getFileBodyPart("c:\\index.html", "text/html");
		multipart.addBodyPart(bp2);

		// Part two is attachment
		messageBodyPart = new MimeBodyPart();
		
		DataSource source =  new FileDataSource(attachmentFile);
		messageBodyPart.setDataHandler( new DataHandler(source));
		messageBodyPart.setFileName(attachmentFile);
		multipart.addBodyPart(messageBodyPart);
		
		// Put parts in message
		message.setContent(multipart);

			// Send the message
			Transport.send( message );
	  }
	 public BodyPart getFileBodyPart(String filename, String contentType)
   throws javax.mail.MessagingException {
      BodyPart bp = new MimeBodyPart();
      bp.setDataHandler(new DataHandler(new FileDataSource(filename)));
      return bp;
}

}
