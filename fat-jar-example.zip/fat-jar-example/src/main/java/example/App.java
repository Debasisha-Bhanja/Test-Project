package example;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class App {

	public static void main(String[] args) {
		//Config config = ConfigFactory.load();
		//System.out.println(config.getString("word1"));
		Path resourceDirectory  = Paths.get("src/main/resources/chromedriver/chromedriver.exe");
		System.out.println(resourceDirectory.toFile().getAbsolutePath()  );
		String exePath =resourceDirectory.toFile().getAbsolutePath();
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver = new ChromeDriver();
		driver.get("http://toolsqa.wpengine.com/automation-practice-form/");
	}

}
